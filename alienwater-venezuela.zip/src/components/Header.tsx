import { useState, useEffect } from 'react';
import { Menu, X, ArrowRight, UserCheck, ShieldCheck, Sparkles } from 'lucide-react';

interface HeaderProps {
  onLoginClick: () => void;
  onQuoteClick: () => void;
  onSectionScroll: (sectionId: string) => void;
  isLoggedIn: boolean;
}

export default function Header({ onLoginClick, onQuoteClick, onSectionScroll, isLoggedIn }: HeaderProps) {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Inicio', id: 'inicio' },
    { name: 'Acerca de', id: 'acerca' },
    { name: 'Beneficios', id: 'beneficios' },
    { name: 'Clientes', id: 'clientes' },
    { name: 'Mapa', id: 'mapa' },
    { name: 'Calculadora', id: 'calculadora' },
  ];

  const handleLinkClick = (id: string) => {
    setMobileMenuOpen(false);
    onSectionScroll(id);
  };

  return (
    <nav
      className={`fixed top-0 inset-x-0 z-40 transition-all duration-350 font-sans ${
        isScrolled
          ? 'bg-slate-950/90 border-b border-slate-800/80 backdrop-blur-md py-3 shadow-lg'
          : 'bg-transparent py-5'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between">
        
        {/* Brand Logo matching original image */}
        <div className="flex items-center gap-2 cursor-pointer" onClick={() => handleLinkClick('inicio')}>
          {/* Logo alien water graphic container */}
          <div className="relative w-9 h-9 bg-linear-to-tr from-cyan-400 to-blue-500 rounded-xl flex items-center justify-center shadow-lg shadow-cyan-500/20">
            {/* Custom SVG inside depicting Alien head combined with a dripping droplet */}
            <svg viewBox="0 0 100 100" className="w-6 h-6 fill-slate-950" xmlns="http://www.w3.org/2500/svg">
              {/* Droplet head contour */}
              <path d="M50 15 C30 45 20 60 20 75 A30 30 0 0 0 80 75 C80 60 70 45 50 15 Z" />
              {/* Alien eye slits left & right */}
              <ellipse cx="38" cy="68" rx="8" ry="4" transform="rotate(-15 38 68)" fill="white" />
              <ellipse cx="62" cy="68" rx="8" ry="4" transform="rotate(15 62 68)" fill="white" />
            </svg>
            <div className="absolute -bottom-0.5 -right-0.5 w-3 h-3 bg-emerald-400 rounded-full border border-slate-950 animate-ping duration-3000" />
            <div className="absolute -bottom-0.5 -right-0.5 w-3 h-3 bg-emerald-400 rounded-full border border-slate-950" />
          </div>
          <div>
            <span className="font-sans font-black text-lg tracking-wider text-white select-none block leading-none">
              Alienwater
            </span>
            <span className="text-[9px] text-cyan-400/85 tracking-widest font-mono font-extrabold block mt-0.5">
              TECNOLOGÍA NACIONAL
            </span>
          </div>
        </div>

        {/* Desktop Links Navigation */}
        <div className="hidden md:flex items-center space-y-0 space-x-7">
          {navLinks.map((link) => (
            <button
              key={link.id}
              onClick={() => handleLinkClick(link.id)}
              className="text-xs lg:text-sm font-semibold tracking-wide text-slate-300 hover:text-cyan-400 cursor-pointer transition-all duration-200"
            >
              {link.name}
            </button>
          ))}
        </div>

        {/* Action button login/portal */}
        <div className="hidden md:flex items-center space-x-4">
          <button
            onClick={onLoginClick}
            className={`px-4.5 py-1.5 rounded-full text-xs font-bold tracking-wider transition-all duration-200 cursor-pointer ${
              isLoggedIn
                ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                : 'border border-slate-700/80 hover:border-cyan-500/60 text-slate-300 hover:text-cyan-400'
            }`}
          >
            {isLoggedIn ? (
              <span className="flex items-center gap-1.5 font-mono">
                <UserCheck className="w-3.5 h-3.5" /> PORTAL ACTIVO
              </span>
            ) : (
              'Iniciar Sesión'
            )}
          </button>
          <button
            onClick={onQuoteClick}
            className="px-4.5 py-1.5 bg-linear-to-r from-cyan-500 to-blue-500 hover:from-cyan-400 hover:to-blue-400 text-slate-950 rounded-full text-xs font-black tracking-wider transition-all duration-300 hover:shadow-cyan-500/20 cursor-pointer shadow-md"
          >
            COTIZAR
          </button>
        </div>

        {/* Mobile menu trigger button */}
        <div className="md:hidden flex items-center">
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-1 text-slate-300 hover:text-white transition-all duration-200 focus:outline-hidden"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile drop menu */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-slate-950/95 border-b border-slate-850 px-4 py-5 space-y-4 shadow-xl backdrop-blur-lg">
          <div className="flex flex-col space-y-3 pb-3 border-b border-slate-900">
            {navLinks.map((link) => (
              <button
                key={link.id}
                onClick={() => handleLinkClick(link.id)}
                className="text-left py-1.5 text-xs uppercase tracking-wider font-bold text-slate-300 hover:text-cyan-400"
              >
                {link.name}
              </button>
            ))}
          </div>
          <div className="flex flex-col gap-3">
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onLoginClick();
              }}
              className="w-full text-center py-2.5 bg-slate-900 text-slate-300 rounded-xl text-xs font-bold border border-slate-800"
            >
              {isLoggedIn ? 'Acceder al Portal Monitoreo' : 'Iniciar Sesión'}
            </button>
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onQuoteClick();
              }}
              className="w-full text-center py-2.5 bg-linear-to-r from-cyan-500 to-blue-500 text-slate-950 font-black rounded-xl text-xs tracking-wider"
            >
              COTIZAR MÁQUINA
            </button>
          </div>
        </div>
      )}
    </nav>
  );
}
