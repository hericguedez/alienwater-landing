/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import About from './components/About';
import Benefits from './components/Benefits';
import Clients from './components/Clients';
import InteractiveMap from './components/InteractiveMap';
import ProfitCalculator from './components/ProfitCalculator';
import Reviews from './components/Reviews';
import IoTTracker from './components/IoTTracker';
import QuoteModal from './components/QuoteModal';
import { Mail, Phone, MapPin, Instagram, Facebook, Linkedin, Twitter } from 'lucide-react';

export default function App() {
  const [isQuoteOpen, setIsQuoteOpen] = useState(false);
  const [isDashboardOpen, setIsDashboardOpen] = useState(false);

  const handleSectionScroll = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  return (
    <div className="bg-slate-950 min-h-screen text-slate-100 selection:bg-cyan-500 selection:text-slate-950 font-sans antialiased overflow-x-hidden">
      
      {/* Header element */}
      <Header
        onLoginClick={() => setIsDashboardOpen(true)}
        onQuoteClick={() => setIsQuoteOpen(true)}
        onSectionScroll={handleSectionScroll}
        isLoggedIn={isDashboardOpen}
      />

      {/* Main visual sections */}
      <main className="relative z-10">
        {/* HERO SECTION */}
        <Hero onQuoteClick={() => setIsQuoteOpen(true)} />

        {/* ABOUT / INNOVACIÓN NACIONAL */}
        <About />

        {/* BENEFITS / BENEFICIOS */}
        <Benefits />

        {/* CLIENTS / RESPALDO */}
        <Clients />

        {/* INTERACTIVE VENEZUELA MAP */}
        <section id="mapa" className="py-24 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <InteractiveMap />
        </section>

        {/* PROFIT PROJECTION CALCULATOR */}
        <section id="calculadora" className="py-24 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <ProfitCalculator />
        </section>

        {/* CUSTOMER REVIEWS */}
        <Reviews />
      </main>

      {/* FOOTER conforming with images */}
      <footer id="contacto" className="bg-slate-950 border-t border-slate-900 py-16 text-slate-400 font-sans relative z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 md:grid-cols-12 gap-8 items-center">
          
          {/* Logo & Slogan Column */}
          <div className="md:col-span-4 space-y-4 text-left">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-linear-to-tr from-cyan-400 to-blue-500 rounded-lg flex items-center justify-center text-slate-950 font-bold text-sm shadow-md">
                AW
              </div>
              <span className="font-sans font-black text-lg tracking-wider text-white">
                Alienwater
              </span>
            </div>
            <p className="text-xs text-slate-500 leading-relaxed font-light font-sans">
              La evolución en la distribución de agua purificada en Venezuela. Maquinaria automatizada robusta con tecnología IoT satelital.
            </p>
          </div>

          {/* Contact Details Column */}
          <div className="md:col-span-4 space-y-2.5 text-xs text-left">
            <h4 className="text-sm font-bold text-slate-200 uppercase tracking-widest font-sans mb-3 select-none">Contacto Directo</h4>
            <div className="flex items-center gap-2.5">
              <MapPin className="w-4 h-4 text-cyan-400 shrink-0" />
              <span>Dirección: Av. Francisco de Miranda, El Recreo, Caracas, Venezuela.</span>
            </div>
            <div className="flex items-center gap-2.5">
              <Phone className="w-4 h-4 text-cyan-400 shrink-0" />
              <span>Teléfono: +58 (212) 630-1090</span>
            </div>
            <div className="flex items-center gap-2.5">
              <Mail className="w-4 h-4 text-cyan-400 shrink-0" />
              <span>Email: contacto@alienwater.ve</span>
            </div>
          </div>

          {/* Social Icons & Copyright */}
          <div className="md:col-span-4 flex flex-col items-center md:items-end space-y-4">
            <div className="flex gap-4">
              <a href="#" className="w-8 h-8 rounded-full bg-slate-900 border border-slate-800 flex items-center justify-center text-slate-400 hover:text-cyan-400 hover:border-cyan-500/50 transition-all duration-200">
                <Facebook className="w-4.5 h-4.5" />
              </a>
              <a href="#" className="w-8 h-8 rounded-full bg-slate-900 border border-slate-800 flex items-center justify-center text-slate-400 hover:text-cyan-400 hover:border-cyan-500/50 transition-all duration-200">
                <Instagram className="w-4.5 h-4.5" />
              </a>
              <a href="#" className="w-8 h-8 rounded-full bg-slate-900 border border-slate-800 flex items-center justify-center text-slate-400 hover:text-cyan-400 hover:border-cyan-500/50 transition-all duration-200">
                <Linkedin className="w-4.5 h-4.5" />
              </a>
              <a href="#" className="w-8 h-8 rounded-full bg-slate-900 border border-slate-800 flex items-center justify-center text-slate-400 hover:text-cyan-400 hover:border-cyan-500/50 transition-all duration-200">
                <Twitter className="w-4.5 h-4.5" />
              </a>
            </div>
            <p className="text-[10px] text-slate-650 font-mono text-center md:text-right">
              © 2026 Alienwater. Todos los derechos reservados. <br />
              Hecho con orgullo en Venezuela.
            </p>
          </div>

        </div>
      </footer>

      {/* OVERLAY: PORTAL IoT TELEMETRÍA */}
      {isDashboardOpen && (
        <IoTTracker onClose={() => setIsDashboardOpen(false)} />
      )}

      {/* MODAL: SOLICITUD DE COTIZACIÓN */}
      <QuoteModal isOpen={isQuoteOpen} onClose={() => setIsQuoteOpen(false)} />

    </div>
  );
}

